<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
.app-main{
  padding: 10px;
}
.el-card{
  margin-bottom: 10px;
}
</style>
